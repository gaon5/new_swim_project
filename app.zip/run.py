from app import app

# When you gonna start, pip install -r requirements.txt

if __name__ == '__main__':
    app.run(debug=True)
